package Practico;

public class arrays {

    public static void main(String[] args) {

        String[] textocadena = {
                "Ariel",
                "Lionel",
                "Marcelo",
                "Jacinto"
        };

        for (int i = 0; i < textocadena.length; i++) {

            System.out.println(textocadena[i]);
        }
    }
}
