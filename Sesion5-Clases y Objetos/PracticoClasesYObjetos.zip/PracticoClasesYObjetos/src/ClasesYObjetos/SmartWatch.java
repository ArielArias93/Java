package ClasesYObjetos;

public class SmartWatch extends SmartDevices {

    int duracionBateria;
    boolean sumergible;

    public SmartWatch() {}

    public SmartWatch(int duracionBateria, boolean sumergible) {
        this.duracionBateria = duracionBateria;
        this.sumergible = sumergible;
    }
}
