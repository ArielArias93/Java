package ClasesYObjetos;

public class SmartDevices {

    String marca;
    String modelo;
    String color;
    double peso;

    public SmartDevices() {}

    public SmartDevices(String marca, String modelo, String color, double peso) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.peso = peso;
    }
}
