package practicoInterfaces;

import java.util.List;

public class CocheCRUDImpl implements CocheCRUD {

    public void Save(Coche coche) {

    }

    @Override
    public List<Coche> FindAll() {
        return null;
    }

    @Override
    public void Delete(Coche coche) {

    }

}
