package com.Ariel;

public class ClasePractico {

    public static void main(String[] args) {

        int numero = 10;
        long numero2 = 15439301;
        double numero3 = 25.50;
        float numero4 = 2.5f;
        byte numero5 = 5;
        short numero6 = 25;

        boolean Valor = true;

        String nombre = "Ariel";
        char variable = 'F';

        System.out.println("El numero Entero es: " + numero);
        System.out.println("El numero Long es: " + numero2);
        System.out.println("El numero Double es: " + numero3);
        System.out.println("El numero Float es: " + numero4);
        System.out.println("El numero Byte es: " + numero5);
        System.out.println("El numero Short es: " + numero6);

        System.out.println("La variable Booleana es: " + Valor);

        System.out.println("El texto String es: " + nombre);
        System.out.println("La variable Char es: " + variable);

    }
}
